import { getSupabaseBrowserClient } from './supabase';

export async function getMyContext() {
  const supabase = getSupabaseBrowserClient();
  const { data, error } = await supabase.rpc('get_my_context');
  if (error) throw error;
  return data as { company_id?: string; company_name?: string; user_id?: string } | null;
}
