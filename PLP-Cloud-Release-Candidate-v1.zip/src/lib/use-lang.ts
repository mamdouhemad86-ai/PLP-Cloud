'use client';
import {useEffect,useState} from 'react';
import type {Language} from '@/types/erp';
export function useLang(){const [lang,setLang]=useState<Language>('ar');useEffect(()=>{const read=()=>setLang(document.documentElement.lang==='en'?'en':'ar');read();const o=new MutationObserver(read);o.observe(document.documentElement,{attributes:true,attributeFilter:['lang']});return()=>o.disconnect()},[]);return lang}
