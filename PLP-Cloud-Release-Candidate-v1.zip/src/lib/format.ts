export function money(value: number | null | undefined, locale = 'ar-EG') {
  return new Intl.NumberFormat(locale, { style: 'currency', currency: 'EGP', maximumFractionDigits: 0 }).format(value ?? 0);
}
