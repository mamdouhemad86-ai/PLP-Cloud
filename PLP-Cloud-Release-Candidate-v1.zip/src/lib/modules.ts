import type { ModuleItem } from '@/types/erp';
export const modules: ModuleItem[] = [
  {key:'dashboard',labelAr:'لوحة التحكم',labelEn:'Dashboard',href:'/',icon:'LayoutDashboard'},
  {key:'sales',labelAr:'المبيعات',labelEn:'Sales',href:'/sales',icon:'ShoppingCart'},
  {key:'purchases',labelAr:'المشتريات والاستيراد',labelEn:'Purchasing & Imports',href:'/purchases',icon:'Truck'},
  {key:'products',labelAr:'المنتجات',labelEn:'Products',href:'/products',icon:'PackageSearch'},
  {key:'inventory',labelAr:'المخزون',labelEn:'Inventory',href:'/inventory',icon:'Boxes'},
  {key:'customers',labelAr:'العملاء',labelEn:'Customers',href:'/customers',icon:'Users'},
  {key:'suppliers',labelAr:'الموردون',labelEn:'Suppliers',href:'/suppliers',icon:'Truck'},
  {key:'operations',labelAr:'العمليات المالية',labelEn:'Operations',href:'/operations',icon:'ReceiptText'},
  {key:'treasury',labelAr:'الخزينة والبنوك',labelEn:'Treasury & Banks',href:'/treasury',icon:'WalletCards'},
  {key:'accounting',labelAr:'المحاسبة',labelEn:'Accounting',href:'/accounting',icon:'Calculator'},
  {key:'reports',labelAr:'التقارير',labelEn:'Reports',href:'/reports',icon:'ChartNoAxesCombined'},
  {key:'employees',labelAr:'الموظفين',labelEn:'Employees',href:'/employees',icon:'Users'},
  {key:'payroll',labelAr:'المرتبات',labelEn:'Payroll',href:'/payroll',icon:'BadgeDollarSign'},
  {key:'assets',labelAr:'الأصول الثابتة',labelEn:'Fixed Assets',href:'/fixed-assets',icon:'Landmark'},
  {key:'partners',labelAr:'الشركاء',labelEn:'Partners',href:'/partners',icon:'Handshake'},
  {key:'admin',labelAr:'الإدارة',labelEn:'Administration',href:'/admin',icon:'Settings2'}
];
