import type { Language } from '@/types/erp';

export const dictionaries = {
  ar: {
    brand: 'PLP Cloud',
    subtitle: 'نظام إدارة Phone LCD Parts',
    dashboard: 'لوحة التحكم',
    sales: 'المبيعات',
    purchases: 'المشتريات والاستيراد',
    inventory: 'المخزون',
    treasury: 'الخزينة والبنوك',
    accounting: 'المحاسبة',
    reports: 'التقارير',
    partners: 'الشركاء',
    employees: 'الموظفين',
    payroll: 'المرتبات',
    assets: 'الأصول الثابتة',
    administration: 'الإدارة',
    liquidity: 'إجمالي السيولة',
    salesToday: 'مبيعات اليوم',
    salesMonth: 'مبيعات الشهر',
    receivables: 'مديونية العملاء',
    payables: 'مستحقات الموردين',
    inventoryValue: 'قيمة المخزون',
    lowStock: 'أصناف منخفضة المخزون',
    imports: 'شحنات استيراد مفتوحة',
    netProfit: 'صافي الربح',
    quickActions: 'إجراءات سريعة',
    newSale: 'فاتورة بيع',
    newPurchase: 'فاتورة شراء',
    receipt: 'تحصيل من عميل',
    payment: 'دفع لمورد',
    transfer: 'تحويل خزينة',
    viewAll: 'عرض الكل',
    loading: 'جاري التحميل...',
    demo: 'وضع المعاينة',
    menu: 'القائمة',
    signOut: 'تسجيل الخروج'
  },
  en: {
    brand: 'PLP Cloud',
    subtitle: 'Phone LCD Parts ERP',
    dashboard: 'Dashboard', sales: 'Sales', purchases: 'Purchasing & Imports',
    inventory: 'Inventory', treasury: 'Treasury & Banks', accounting: 'Accounting',
    reports: 'Reports', partners: 'Partners', employees: 'Employees', payroll: 'Payroll',
    assets: 'Fixed Assets', administration: 'Administration', liquidity: 'Total Liquidity',
    salesToday: 'Sales Today', salesMonth: 'Sales This Month', receivables: 'Customer Receivables',
    payables: 'Supplier Payables', inventoryValue: 'Inventory Value', lowStock: 'Low Stock Items',
    imports: 'Open Import Shipments', netProfit: 'Net Profit', quickActions: 'Quick Actions',
    newSale: 'Sales Invoice', newPurchase: 'Purchase Invoice', receipt: 'Customer Receipt',
    payment: 'Supplier Payment', transfer: 'Treasury Transfer', viewAll: 'View All',
    loading: 'Loading...', demo: 'Preview Mode', menu: 'Menu', signOut: 'Sign out'
  }
} as const;

export type Dictionary = typeof dictionaries.ar;
export function getDictionary(lang: Language): Dictionary { return dictionaries[lang] as Dictionary; }
