'use client';
import {useEffect,useState} from 'react';
import {getSupabaseBrowserClient} from '@/lib/supabase';
import {getMyContext} from '@/lib/company';
import {getDictionary} from '@/lib/i18n';
import {money} from '@/lib/format';
import {KpiCard} from '@/components/kpi-card';
import {Icon} from '@/components/icon';
import Link from 'next/link';
import type {DashboardSummary,Language} from '@/types/erp';

const demo:DashboardSummary={sales_today:0,sales_month:0,purchases_today:0,purchases_month:0,customer_receivables:0,supplier_payables:0,inventory_value:0,cash:0,banks:0,wallets:0,total_liquidity:0,cogs_month:0,expenses_month:0,net_profit_month:0,low_stock_count:0,open_import_shipments:0,as_of:new Date().toISOString()};
export default function Dashboard(){const [data,setData]=useState(demo);const [lang,setLang]=useState<Language>('ar');
 useEffect(()=>{const read=()=>setLang(document.documentElement.lang==='en'?'en':'ar');read();const o=new MutationObserver(read);o.observe(document.documentElement,{attributes:true});return()=>o.disconnect()},[]);
 useEffect(()=>{let mounted=true;const load=async()=>{try{const s=getSupabaseBrowserClient();const ctx=await getMyContext();if(!ctx?.company_id)return;const {data,error}=await s.rpc('get_dashboard_summary',{p_company_id:ctx.company_id});if(!error&&data&&mounted)setData({...demo,...data});}catch{} };load();return()=>{mounted=false}},[]);
 const t=getDictionary(lang); return <div className="content"><div><h1 className="pageTitle">{t.dashboard}</h1><div className="pageSub">{lang==='ar'?'نظرة سريعة على حركة الشركة والسيولة والمخزون':'A quick view of company performance, liquidity and inventory'}</div></div>
 <div className="grid kpiGrid"><KpiCard label={t.liquidity} value={money(data.total_liquidity)} hint={`${t.cash}: ${money(data.cash)}`} icon="WalletCards" accent/><KpiCard label={t.salesToday} value={money(data.sales_today)} hint={`${t.salesMonth}: ${money(data.sales_month)}`} icon="ShoppingCart"/><KpiCard label={t.receivables} value={money(data.customer_receivables)} icon="Users"/><KpiCard label={t.inventoryValue} value={money(data.inventory_value)} hint={`${t.lowStock}: ${data.low_stock_count}`} icon="Boxes"/></div>
 <div className="grid dashboardGrid"><div className="card"><div className="sectionHead"><h2>{t.quickActions}</h2><button className="pill">{t.viewAll}</button></div><div className="grid quickGrid">{[["newSale","ReceiptText"],["newPurchase","FilePlus2"],["receipt","HandCoins"],["payment","BadgeDollarSign"]].map(([key,icon])=><Link className="action" key={key} href={key==='newSale'?'/sales':key==='newPurchase'?'/purchases':key==='receipt'||key==='payment'?'/operations':'/'}><span className="actionIcon"><Icon name={icon}/></span><span>{t[key as keyof typeof t]}</span></button>)}</div></div>
 <div className="card"><div className="sectionHead"><h2>{lang==='ar'?'تنبيهات النظام':'System Alerts'}</h2><Icon name="Bell"/></div><div className="alert">{data.low_stock_count>0?`${data.low_stock_count} ${t.lowStock}`:lang==='ar'?'لا توجد تنبيهات مخزون حالياً':'No inventory alerts right now'}</div><div className="alert">{data.open_import_shipments>0?`${data.open_import_shipments} ${t.imports}`:lang==='ar'?'لا توجد شحنات استيراد مفتوحة':'No open import shipments'}</div></div></div>
 <div className="grid kpiGrid" style={{marginTop:16}}><KpiCard label={t.netProfit} value={money(data.net_profit_month)} icon="TrendingUp"/><KpiCard label={t.payables} value={money(data.supplier_payables)} icon="Truck"/><KpiCard label={lang==='ar'?'البنوك':'Banks'} value={money(data.banks)} icon="Landmark"/><KpiCard label={lang==='ar'?'المحافظ الإلكترونية':'Digital Wallets'} value={money(data.wallets)} icon="Smartphone"/></div>
 </div>}
