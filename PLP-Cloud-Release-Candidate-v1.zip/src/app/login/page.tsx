'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { getSupabaseBrowserClient } from '@/lib/supabase';
import { Icon } from '@/components/icon';

export default function LoginPage() {
  const router = useRouter();
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  const [busy,setBusy]=useState(false); const [error,setError]=useState('');
  async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setError('');
    const {error}=await getSupabaseBrowserClient().auth.signInWithPassword({email,password});
    setBusy(false); if(error){setError(error.message);return;} router.replace('/'); router.refresh();
  }
  return <main className="authPage"><div className="authCard"><div className="brand authBrand"><div className="logo">PLP</div><div><strong>PLP Cloud</strong><small>Mobile Parts ERP</small></div></div><h1>تسجيل الدخول</h1><p>ادخل إلى نظام إدارة شركة PLP</p><form onSubmit={submit}><label>البريد الإلكتروني<input required type="email" value={email} onChange={e=>setEmail(e.target.value)} /></label><label>كلمة المرور<input required type="password" value={password} onChange={e=>setPassword(e.target.value)} /></label>{error&&<div className="formError">{error}</div>}<button className="primaryBtn" disabled={busy}>{busy?'جاري الدخول...':'دخول'} <Icon name="ArrowLeft"/></button></form></div></main>
}
