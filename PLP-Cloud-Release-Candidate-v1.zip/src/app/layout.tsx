import './globals.css';
import type { Metadata } from 'next';
import { AppShell } from '@/components/app-shell';

export const metadata: Metadata = { title: 'PLP Cloud', description: 'PLP Phone LCD Parts ERP System' };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="ar" dir="rtl"><body><AppShell>{children}</AppShell></body></html>; }
