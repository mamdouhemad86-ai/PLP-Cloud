'use client';
import {Icon} from './icon';
import {getDictionary} from '@/lib/i18n';
import {useLang} from '@/lib/use-lang';

export function ModulePage({titleAr,titleEn,descriptionAr,descriptionEn,icon='LayoutDashboard',children}:{titleAr:string;titleEn:string;descriptionAr:string;descriptionEn:string;icon?:string;children?:React.ReactNode}){
 const lang=useLang(); const t=getDictionary(lang);
 return <div className="content"><div className="pageHeader"><div><div className="eyebrow"><Icon name={icon}/><span>PLP Cloud</span></div><h1 className="pageTitle">{lang==='ar'?titleAr:titleEn}</h1><div className="pageSub">{lang==='ar'?descriptionAr:descriptionEn}</div></div></div>{children}</div>
}
