'use client';
import * as Icons from 'lucide-react';
export function Icon({name,size=19}:{name:string,size?:number}) { const C=(Icons as Record<string, any>)[name] ?? Icons.Circle; return <C size={size} strokeWidth={1.9}/>; }
