'use client';
import {useState} from 'react';
import {Icon} from './icon';
export function EntityForm({title,children,onClose}:{title:string;children:React.ReactNode;onClose:()=>void}){return <div className="modalBackdrop"><div className="modal"><div className="modalHead"><h2>{title}</h2><button className="iconBtn" onClick={onClose}><Icon name="X"/></button></div>{children}</div></div>}
export function Field({label,value,onChange,type='text',placeholder}:{label:string;value:string;onChange:(v:string)=>void;type?:string;placeholder?:string}){return <label className="field"><span>{label}</span><input value={value} onChange={e=>onChange(e.target.value)} type={type} placeholder={placeholder}/></label>}
export function SelectField({label,value,onChange,options}:{label:string;value:string;onChange:(v:string)=>void;options:{value:string;label:string}[]}){return <label className="field"><span>{label}</span><select value={value} onChange={e=>onChange(e.target.value)}><option value="">—</option>{options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select></label>}
export function useBusy(){const [busy,setBusy]=useState(false);return {busy,setBusy}}
