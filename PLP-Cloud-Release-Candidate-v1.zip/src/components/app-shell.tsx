'use client';
import {useEffect,useState} from 'react';
import Link from 'next/link';
import {usePathname} from 'next/navigation';
import {Icon} from './icon';
import {modules} from '@/lib/modules';
import {getDictionary} from '@/lib/i18n';
import {getSupabaseBrowserClient} from '@/lib/supabase';
import type {Language} from '@/types/erp';

export function AppShell({children}:{children:React.ReactNode}){
 const [lang,setLang]=useState<Language>('ar'); const [open,setOpen]=useState(false); const [checking,setChecking]=useState(true); const [userEmail,setUserEmail]=useState(''); const path=usePathname(); const t=getDictionary(lang);
 useEffect(()=>{document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr'},[lang]);
 useEffect(()=>{if(path==='/login'){setChecking(false);return;} let mounted=true; const supabase=getSupabaseBrowserClient(); supabase.auth.getUser().then(({data})=>{if(!mounted)return;if(!data.user){window.location.href='/login';return;} setUserEmail(data.user.email||'');setChecking(false)}); return()=>{mounted=false}},[path]);
 if(path==='/login') return <>{children}</>;
 if(checking) return <div className="loadingPage">PLP Cloud</div>;
 return <div className="shell" dir={lang==='ar'?'rtl':'ltr'}>
  <aside className={`sidebar ${open?'open':''}`}><div className="brand"><div className="logo">PLP</div><div><strong>{t.brand}</strong><small>{t.subtitle}</small></div></div>
   <nav className="nav">{modules.map(m=><Link key={m.key} href={m.href} className={path===m.href?'active':''} onClick={()=>setOpen(false)}><Icon name={m.icon}/><span>{lang==='ar'?m.labelAr:m.labelEn}</span></Link>)}</nav>
  </aside>
  <main className="main"><header className="topbar"><div className="topActions"><button className="pill mobileMenu" onClick={()=>setOpen(!open)}><Icon name="Menu"/></button><span className="pill desktopOnly">{t.demo}</span></div><div className="topActions"><button className="pill" onClick={()=>setLang(lang==='ar'?'en':'ar')}>{lang==='ar'?'EN':'عربي'}</button><button className="pill" onClick={async()=>{await getSupabaseBrowserClient().auth.signOut();window.location.href='/login'}}>خروج</button><div className="userChip"><div className="avatar">م</div><span className="desktopOnly">{userEmail||'PLP User'}</span></div></div></header>{children}</main>
 </div>
}
