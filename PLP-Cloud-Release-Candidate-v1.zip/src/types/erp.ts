export type Language = 'ar' | 'en';
export type Direction = 'rtl' | 'ltr';

export interface DashboardSummary {
  sales_today: number;
  sales_month: number;
  purchases_today: number;
  purchases_month: number;
  customer_receivables: number;
  supplier_payables: number;
  inventory_value: number;
  cash: number;
  banks: number;
  wallets: number;
  total_liquidity: number;
  cogs_month: number;
  expenses_month: number;
  net_profit_month: number;
  low_stock_count: number;
  open_import_shipments: number;
  as_of: string;
}

export interface ModuleItem { key: string; labelAr: string; labelEn: string; href: string; icon: string; }
