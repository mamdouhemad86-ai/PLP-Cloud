# PLP Cloud — Phone LCD Parts ERP

A production-oriented ERP frontend foundation for PLP (Phone LCD Parts), built with **Next.js + React + TypeScript + Supabase**.

## Included in this version
- Arabic / English UI with RTL / LTR switching
- Responsive desktop / tablet / mobile shell
- Supabase authentication login/logout
- Authenticated company context through `get_my_context`
- Live dashboard through `get_dashboard_summary`
- Live Inventory summary through `get_product_stock_summary`
- Operational Sales, Purchasing and Treasury screens connected to the existing PLP database
- Module landing screens for Products, Customers, Suppliers, Accounting, Reports, Employees, Payroll, Fixed Assets, Partners and Administration
- Treasury/liquidity KPIs
- Navigation for Sales, Purchasing & Imports, Products, Inventory, Customers, Suppliers, Operations, Treasury, Accounting, Reports, Employees, Payroll, Fixed Assets, Partners and Administration
- `.env.example` and GitHub-safe `.gitignore`
- No Supabase secrets committed

## Run locally

```bash
cp .env.example .env.local
# Fill the PLP Supabase URL and anon key
npm install
npm run dev
```

Open `http://localhost:3000`.

## Supabase

This frontend is intended for the **PLP Cloud Supabase project only**. Do **not** point it at TN Auto.

Expected backend RPCs already exist in the PLP project, including:
- `get_my_context`
- `get_dashboard_summary`
- `get_product_stock_summary`

## Important

The repository is intentionally split into a frontend layer and the existing PLP Supabase backend. Database logic, RLS, permissions, accounting, inventory, sales, purchasing/imports, treasury, employees, payroll and fixed-assets engines remain in Supabase.

The remaining frontend work is to turn the existing module placeholders into complete CRUD/workflow screens for every RPC already available in the backend.

## GitHub

Upload the contents of this folder to a new repository. Never commit `.env.local`, service-role keys, passwords, or other secrets.
